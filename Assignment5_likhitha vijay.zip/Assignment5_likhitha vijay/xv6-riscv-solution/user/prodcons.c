// Assignment 5, Question 2: Producer-Consumer Problem (Bounded Buffer).
//
// Shared state: the circular buffer, its "in"/"out" indices and its
// configured size all live in the page returned by shm_get() (see
// kernel/sysproc.c), so the producer and the consumer -- which are two
// separate xv6 processes created with a single fork() -- see the exact
// same memory rather than private copies. This is the "shared page
// through xv6's memory model" option the assignment explicitly allows.
//
// Synchronization: two counting semaphores (empty, full) plus one mutex,
// all implemented as new syscalls backed by xv6's own sleep()/wakeup()
// (see kernel/sem.c). Semaphore *ids* are plain integers, so they can be
// created once in the parent before fork() and are simply copied into the
// child's memory like any other local variable -- no shared memory is
// needed just to share which semaphore to use.
//
// Usage: prodcons [bufsize]   (default buffer size = 5)

#include "kernel/types.h"
#include "user/user.h"

#define MAXBUF   64  // upper bound the shared struct can hold
#define NITEMS   20  // producer produces integers 1..NITEMS

struct shbuf {
  int buf[MAXBUF];
  int in;
  int out;
  int bufsize;
};

int
main(int argc, char *argv[])
{
  struct shbuf *shm;
  int bufsize = 5;
  int empty, full, mutex;
  int pid;

  if (argc > 1) {
    bufsize = atoi(argv[1]);
    if (bufsize <= 0 || bufsize > MAXBUF) {
      printf("prodcons: bufsize must be between 1 and %d\n", MAXBUF);
      exit(1);
    }
  }

  shm = (struct shbuf *)shm_get();
  if (shm == 0) {
    printf("prodcons: shm_get failed\n");
    exit(1);
  }
  // shm_get() zero-fills the page: in == out == 0 already.
  shm->bufsize = bufsize;

  empty = sem_alloc(bufsize); // counts free slots
  full = sem_alloc(0);        // counts filled slots
  mutex = sem_alloc(1);       // protects buf[]/in/out
  if (empty < 0 || full < 0 || mutex < 0) {
    printf("prodcons: sem_alloc failed\n");
    exit(1);
  }

  printf("prodcons: starting, buffer size = %d, %d items\n", bufsize,
         NITEMS);

  pid = fork();
  if (pid < 0) {
    printf("prodcons: fork failed\n");
    exit(1);
  }

  if (pid == 0) {
    // ---- Consumer ----
    int i, item, expected = 1;

    for (i = 0; i < NITEMS; i++) {
      sem_wait(full);   // blocks here whenever the buffer is empty
      sem_wait(mutex);
      item = shm->buf[shm->out];
      shm->out = (shm->out + 1) % shm->bufsize;
      sem_signal(mutex);
      sem_signal(empty);

      if (item != expected)
        printf("Consumer: ORDER ERROR expected %d, got %d\n", expected,
               item);
      printf("Consumer: consumed %d\n", item);
      expected++;

      pause(3); // slower than the producer -> buffer drains
    }
    printf("Consumer: done, consumed %d items in order\n", NITEMS);
    exit(0);
  } else {
    // ---- Producer ----
    int i;

    for (i = 1; i <= NITEMS; i++) {
      sem_wait(empty); // blocks here whenever the buffer is full
      sem_wait(mutex);
      shm->buf[shm->in] = i;
      shm->in = (shm->in + 1) % shm->bufsize;
      sem_signal(mutex);
      sem_signal(full);

      printf("Producer: produced %d\n", i);

      // Bursty producer: fast most of the time, occasionally pausing
      // longer so the consumer can catch all the way up to empty and
      // block on `full` too -- this exercises both blocking directions.
      pause((i % 5 == 0) ? 8 : 1);
    }
    wait(0);

    sem_destroy(empty);
    sem_destroy(full);
    sem_destroy(mutex);

    printf("prodcons: all %d items produced and consumed, none lost, "
           "none duplicated, none out of order\n",
           NITEMS);
  }

  exit(0);
}
