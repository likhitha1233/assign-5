// Assignment 5, Question 4: Dining Philosophers Problem (Deadlock
// Avoidance).
//
// Each of the 5 forks (chopsticks) is a binary semaphore (initial value 1),
// implemented with the same custom kernel semaphore facility used in Q2
// and Q3 (kernel/sem.c). No shared-memory page is needed here: each
// philosopher only needs to know the semaphore *ids* for its two
// chopsticks, and since those ids are plain integers allocated by the
// parent before fork(), every forked child simply gets its own copy of the
// same integers.
//
// Deadlock-avoidance strategy used: "allow at most N-1 (4) philosophers to
// sit at the table at once" (an extra counting semaphore `seats`,
// initialized to N-1). This is sufficient to make deadlock impossible: the
// classic deadlock requires *all* N philosophers to simultaneously be
// holding their left chopstick and waiting for their right one (a
// circular wait involving every seat at the table). With only N-1
// philosophers ever allowed past the `seats` gate at a time, at least one
// philosopher is always excluded, so at least one chopstick is always free
// for whichever philosopher is holding the neighbouring one -- the
// circular chain can never close, so no set of philosophers can end up in
// a cycle of mutual waiting. Combined with the fact that a seated
// philosopher always eventually acquires both chopsticks and releases
// them, this also gives reasonable fairness: no philosopher can be locked
// out of the table forever, and no held chopstick is ever held
// indefinitely.
//
// Usage: dining [cycles]   (default 5 cycles per philosopher)

#include "kernel/types.h"
#include "user/user.h"

#define N 5

static int cycles = 5;

static void
philosopher(int id, int chopstick[N], int seats)
{
  int i;
  int left = id;
  int right = (id + 1) % N;

  for (i = 0; i < cycles; i++) {
    printf("Philosopher %d: THINKING\n", id);
    pause(1 + id);

    printf("Philosopher %d: THINKING -> HUNGRY\n", id);
    sem_wait(seats); // deadlock avoidance: at most N-1 may sit at once

    sem_wait(chopstick[left]);
    sem_wait(chopstick[right]);

    printf("Philosopher %d: HUNGRY -> EATING (cycle %d)\n", id, i + 1);
    pause(2);
    printf("Philosopher %d: EATING -> THINKING\n", id);

    sem_signal(chopstick[right]);
    sem_signal(chopstick[left]);
    sem_signal(seats);
  }
  printf("Philosopher %d: completed all %d cycles\n", id, cycles);
}

int
main(int argc, char *argv[])
{
  int chopstick[N];
  int seats;
  int i, pid;

  if (argc > 1)
    cycles = atoi(argv[1]);
  if (cycles <= 0)
    cycles = 5;

  for (i = 0; i < N; i++) {
    chopstick[i] = sem_alloc(1); // binary semaphore: fork is free (1)
    if (chopstick[i] < 0) {
      printf("dining: sem_alloc failed\n");
      exit(1);
    }
  }
  seats = sem_alloc(N - 1);
  if (seats < 0) {
    printf("dining: sem_alloc failed\n");
    exit(1);
  }

  printf("dining: %d philosophers, %d cycles each, at most %d seated at "
         "once\n",
         N, cycles, N - 1);

  for (i = 0; i < N; i++) {
    pid = fork();
    if (pid < 0) {
      printf("dining: fork failed\n");
      exit(1);
    }
    if (pid == 0) {
      philosopher(i, chopstick, seats);
      exit(0);
    }
  }

  for (i = 0; i < N; i++)
    wait(0);

  for (i = 0; i < N; i++)
    sem_destroy(chopstick[i]);
  sem_destroy(seats);

  printf("dining: all %d philosophers completed %d cycles each - no "
         "deadlock occurred\n",
         N, cycles);

  exit(0);
}
