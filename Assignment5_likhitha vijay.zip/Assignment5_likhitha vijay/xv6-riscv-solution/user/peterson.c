// Assignment 5, Question 1: Mutual Exclusion using Peterson's Algorithm.
//
// Two processes (a parent, id 0, and one child, id 1) share a single
// physical page obtained through the new shm_get() syscall (see
// kernel/sysproc.c / kernel/proc.c). Inside that page we lay out exactly
// the state Peterson's algorithm needs:
//
//     shm[0] = flag[0]
//     shm[1] = flag[1]
//     shm[2] = turn
//     shm[3] = shared_counter
//
// Mutual exclusion between the two processes is enforced *purely* with
// these variables and a busy-wait loop -- no xv6 lock, semaphore, or other
// OS-provided synchronization primitive is used for the critical section
// itself, exactly as the assignment requires.

#include "kernel/types.h"
#include "user/user.h"

#define ITERS 10

#define FLAG(shm, i)   (shm[i])
#define TURN(shm)      (shm[2])
#define COUNTER(shm)   (shm[3])

// A short, pure busy-loop used for the "remainder section" delay. We use a
// plain spin instead of pause() so that this remainder-section delay is not
// itself dependent on any synchronization primitive.
static void
delay(void)
{
  volatile int i;
  for (i = 0; i < 200000; i++)
    ;
}

static void
peterson(volatile int *shm, int id)
{
  int other = 1 - id;
  int i;

  for (i = 0; i < ITERS; i++) {
    // Entry section.
    FLAG(shm, id) = 1;
    TURN(shm) = other;
    while (FLAG(shm, other) == 1 && TURN(shm) == other)
      ; // busy-wait

    // ---- Critical section ----
    COUNTER(shm) = COUNTER(shm) + 1;
    printf("Process %d in CS, counter = %d\n", id, COUNTER(shm));
    // ---------------------------

    // Exit section.
    FLAG(shm, id) = 0;

    // Remainder section.
    delay();
  }
}

int
main(void)
{
  volatile int *shm;
  int pid;

  shm = (volatile int *)shm_get();
  if (shm == 0) {
    printf("peterson: shm_get failed\n");
    exit(1);
  }

  // shm_get() zero-fills the page, so flag[0]=flag[1]=turn=counter=0
  // already; no extra initialization is required.

  pid = fork();
  if (pid < 0) {
    printf("peterson: fork failed\n");
    exit(1);
  }

  if (pid == 0) {
    // Child = process 1.
    peterson(shm, 1);
  } else {
    // Parent = process 0.
    peterson(shm, 0);
    wait(0);
    printf("peterson: done, final shared_counter = %d (expected %d)\n",
           COUNTER(shm), 2 * ITERS);
  }

  exit(0);
}
