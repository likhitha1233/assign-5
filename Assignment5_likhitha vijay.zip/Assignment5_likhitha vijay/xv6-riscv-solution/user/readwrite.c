// Assignment 5, Question 3: Readers-Writers Problem.
//
// shared_data and read_count live in the page returned by shm_get(), shared
// by every reader/writer child (all forked from this same parent, after
// the parent has already called shm_get() -- see kernel/proc.c's kfork()
// for how the mapping is propagated).
//
// Synchronization uses three semaphores (the classical "third
// readers-writers problem" / fair solution):
//
//   mutex  - protects read_count
//   wrt    - held by a writer while writing, and by the *first* reader
//            to arrive / released by the *last* reader to leave, so it
//            really means "some reader or writer is using shared_data"
//   queue  - a short-lived fairness gate that both readers and writers
//            must pass through before requesting access
//
// Readers can still run concurrently with each other (queue is only held
// long enough to register/deregister as a reader), but because writers
// also have to pass through the same queue in arrival order, a writer can
// never be starved by an unbroken stream of readers that keep arriving
// after it -- which is exactly the "readers have priority, but no reader
// should starve writers indefinitely" requirement.
//
// Usage: readwrite [cycles]   (default 4 cycles per process)

#include "kernel/types.h"
#include "user/user.h"

#define NREADERS 3
#define NWRITERS 2

struct shdata {
  int shared_data;
  int read_count;
};

static int cycles = 4;

static void
do_reader(struct shdata *shm, int id, int mutex, int wrt, int queue)
{
  int i, snapshot, active;

  for (i = 0; i < cycles; i++) {
    sem_wait(queue);
    sem_wait(mutex);
    shm->read_count++;
    if (shm->read_count == 1)
      sem_wait(wrt); // first reader locks writers out
    sem_signal(mutex);
    sem_signal(queue);

    snapshot = shm->shared_data;
    active = shm->read_count;
    printf("[t=%d] Reader %d (pid %d): reading shared_data = %d (active "
           "readers = %d)\n",
           uptime(), id, getpid(), snapshot, active);
    pause(2); // simulate the read taking a little while

    sem_wait(mutex);
    shm->read_count--;
    if (shm->read_count == 0)
      sem_signal(wrt); // last reader lets a writer in
    sem_signal(mutex);

    pause(1 + id); // stagger readers so interleaving is visible
  }
  printf("Reader %d (pid %d): finished %d read cycles\n", id, getpid(),
         cycles);
}

static void
do_writer(struct shdata *shm, int id, int wrt, int queue)
{
  int i, newval;

  for (i = 0; i < cycles; i++) {
    sem_wait(queue);
    sem_wait(wrt); // exclusive access: no reader or other writer active
    newval = shm->shared_data + 1;
    shm->shared_data = newval;
    printf("[t=%d] Writer %d (pid %d): WROTE shared_data = %d (exclusive "
           "access)\n",
           uptime(), id, getpid(), newval);
    pause(3); // simulate the write taking a little while
    sem_signal(wrt);
    sem_signal(queue);

    pause(2 + id);
  }
  printf("Writer %d (pid %d): finished %d write cycles\n", id, getpid(),
         cycles);
}

int
main(int argc, char *argv[])
{
  struct shdata *shm;
  int mutex, wrt, queue;
  int i, pid;

  if (argc > 1)
    cycles = atoi(argv[1]);
  if (cycles <= 0)
    cycles = 4;

  shm = (struct shdata *)shm_get();
  if (shm == 0) {
    printf("readwrite: shm_get failed\n");
    exit(1);
  }
  // shared_data == read_count == 0 already, courtesy of shm_get()'s
  // zero-filled page.

  mutex = sem_alloc(1);
  wrt = sem_alloc(1);
  queue = sem_alloc(1);
  if (mutex < 0 || wrt < 0 || queue < 0) {
    printf("readwrite: sem_alloc failed\n");
    exit(1);
  }

  printf("readwrite: starting %d readers, %d writers, %d cycles each\n",
         NREADERS, NWRITERS, cycles);

  for (i = 0; i < NREADERS + NWRITERS; i++) {
    pid = fork();
    if (pid < 0) {
      printf("readwrite: fork failed\n");
      exit(1);
    }
    if (pid == 0) {
      if (i < NREADERS)
        do_reader(shm, i, mutex, wrt, queue);
      else
        do_writer(shm, i - NREADERS, wrt, queue);
      exit(0);
    }
  }

  for (i = 0; i < NREADERS + NWRITERS; i++)
    wait(0);

  sem_destroy(mutex);
  sem_destroy(wrt);
  sem_destroy(queue);

  printf("readwrite: all readers and writers finished, final "
         "shared_data = %d (expected %d)\n",
         shm->shared_data, NWRITERS * cycles);

  exit(0);
}
