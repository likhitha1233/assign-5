// Assignment 5 (Process Synchronization): custom kernel semaphore
// implementation, backed directly by xv6's sleep_prepare()/sleep()/wakeup(),
// exactly as suggested for Question 2 of the assignment. Used to build the
// producer-consumer bounded buffer (Q2), the readers-writers solution (Q3),
// and the dining-philosophers chopsticks / seating limit (Q4).

#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "sem.h"
#include "proc.h"
#include "defs.h"

static struct ksem semtable[NSEM];

// Called once at boot from main().
void
seminit(void)
{
  int i;

  for (i = 0; i < NSEM; i++) {
    initlock(&semtable[i].lock, "ksem");
    semtable[i].value = 0;
    semtable[i].valid = 0;
  }
}

// Allocate a fresh semaphore initialized to `value`.
// Returns its id (0..NSEM-1), or -1 if the table is full.
int
sem_alloc(int value)
{
  int i;

  for (i = 0; i < NSEM; i++) {
    acquire(&semtable[i].lock);
    if (semtable[i].valid == 0) {
      semtable[i].valid = 1;
      semtable[i].value = value;
      release(&semtable[i].lock);
      return i;
    }
    release(&semtable[i].lock);
  }
  return -1;
}

// P() / wait(): block while the value is <= 0, then decrement it.
// Follows the same sleep_prepare()/release()/sleep()/acquire() pattern
// used by xv6's own pipe implementation, so no wakeup can be lost.
int
sem_wait(int id)
{
  struct ksem *s;

  if (id < 0 || id >= NSEM)
    return -1;
  s = &semtable[id];

  acquire(&s->lock);
  if (!s->valid) {
    release(&s->lock);
    return -1;
  }
  while (s->value <= 0) {
    if (killed(myproc())) {
      release(&s->lock);
      return -1;
    }
    sleep_prepare(s);
    release(&s->lock);
    sleep();
    acquire(&s->lock);
    if (!s->valid) {
      release(&s->lock);
      return -1;
    }
  }
  s->value--;
  release(&s->lock);
  return 0;
}

// V() / signal(): increment the value and wake any single waiter blocked
// in sem_wait() (wakeup() itself wakes everyone sleeping on this channel;
// exactly one of them will see value > 0 and proceed, the rest loop back
// to sleep, which is the standard, safe way to implement this on top of
// xv6's broadcast-style wakeup()).
int
sem_signal(int id)
{
  struct ksem *s;

  if (id < 0 || id >= NSEM)
    return -1;
  s = &semtable[id];

  acquire(&s->lock);
  if (!s->valid) {
    release(&s->lock);
    return -1;
  }
  s->value++;
  wakeup(s);
  release(&s->lock);
  return 0;
}

// Release a semaphore slot for reuse. Callers must ensure no process is
// still waiting on it (e.g. destroy only after all workers have exited).
int
sem_destroy(int id)
{
  struct ksem *s;

  if (id < 0 || id >= NSEM)
    return -1;
  s = &semtable[id];

  acquire(&s->lock);
  s->valid = 0;
  release(&s->lock);
  return 0;
}
