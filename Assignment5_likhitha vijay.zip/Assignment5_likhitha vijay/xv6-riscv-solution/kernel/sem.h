// Assignment 5 (Process Synchronization): a small kernel-level counting
// semaphore facility, implemented on top of xv6's own sleep()/wakeup().
//
// Semaphores live in a fixed-size global table (like xv6's pipes or open
// files) and are referred to by user programs through a small integer id.
// Because the table is global kernel state (not per-address-space), the id
// can be shared with any other process -- typically by setting it up in a
// parent before fork(), so every forked child inherits the same id as a
// plain integer in its copied memory. No shared memory page is required
// just to share a semaphore id.

#define NSEM 64

struct ksem {
  struct spinlock lock; // protects value/valid and guards the sleep loop
  int value;            // classic counting-semaphore value
  int valid;            // 1 while this slot is allocated to someone
};
